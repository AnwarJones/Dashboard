var DashboardDemo;
(function (DashboardDemo) {
    var DashboardService = (function () {
        //public total() {
        //    return this.$http.get('/api/citrecaps/totals').then((results) => {
        //        return results.data
        //    });
        //}
        //public citAverage() {
        //    return this.$http.get('/api/citrecaps/average').then((results) => {
        //        return results.data
        //    });
        //}
        function DashboardService($resource, $http) {
            this.$http = $http;
            this.citResource = $resource('/api/citrecaps/:id');
            this.vehicleArResource = $resource('/api/vehiclear/:id');
        }
        DashboardService.prototype.listVAR = function () {
            return this.vehicleArResource.query();
        };
        DashboardService.prototype.getV_AR = function (id) {
            return this.vehicleArResource.get({ id: id });
        };
        DashboardService.prototype.listCits = function () {
            return this.citResource.query();
        };
        DashboardService.prototype.get = function (id) {
            return this.citResource.get({ id: id });
        };
        return DashboardService;
    })();
    DashboardDemo.DashboardService = DashboardService;
    angular.module('DashboardDemo').service('dashboardService', DashboardService);
})(DashboardDemo || (DashboardDemo = {}));
