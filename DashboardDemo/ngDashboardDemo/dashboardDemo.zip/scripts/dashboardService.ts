﻿namespace DashboardDemo {

    export class DashboardService {
        private citResource;
        public vehicleArResource;

        public listVAR() {
            return this.vehicleArResource.query();
        }

        public getV_AR(id) {
            return this.vehicleArResource.get({ id: id });
        }


        public listCits() {
            return this.citResource.query();
        }

        public get(id) {
            return this.citResource.get({ id: id });
        }
        //public total() {
        //    return this.$http.get('/api/citrecaps/totals').then((results) => {
        //        return results.data
        //    });
        //}
        //public citAverage() {
        //    return this.$http.get('/api/citrecaps/average').then((results) => {
        //        return results.data
        //    });
        //}

        constructor($resource: ng.resource.IResourceService, private $http: ng.IHttpService) {
            this.citResource = $resource('/api/citrecaps/:id'); 
            this.vehicleArResource = $resource('/api/vehiclear/:id');
           
        
        }
    

    }
    angular.module('DashboardDemo').service('dashboardService', DashboardService);
    
}