﻿namespace DashboardDemo {



    export class DashboardController {
        public citRecaps;
        public citTotal;
        public citAvg = 0;
        public citCount = 0;


        public vehicleARs;
        public amountDue = 0;
        public numberDue = 0;
        public ARavg = 0;
        public ageAve = 0;

                


        constructor(private dashboardService: DashboardDemo.DashboardService, private $location: ng.ILocationService) {
            //Get the CIT values and populate the associated variables with their values
            this.citRecaps = dashboardService.listCits().$promise.then((results) => {
                let tempsum = 0;
                for (let i = 0; i < results.length; i++) {
                    this.citCount++;
                    tempsum += results[i].transactionAmount;
                }
                this.citAvg = tempsum / this.citCount;
                this.citTotal = tempsum; 
            })
            //Get the vehicle ARs and populate the variables with their values
            this.vehicleARs = dashboardService.listVAR().$promise.then((results) => {
                let tempsum = 0;
                let tempAge = 0;
                for (let i = 0; i < results.length; i++) {
                    this.numberDue++;
                    tempsum += results[i].transactionAmount;
                    tempAge += results[i].age;
                }
                this.ARavg = tempsum / this.numberDue;
                this.amountDue = tempsum;
                this.ageAve = Math.round(tempAge / this.numberDue);
            })            
        }
    }
    angular.module('DashboardDemo').controller('dashboardController', DashboardController);
}