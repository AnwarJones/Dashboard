var DashboardDemo;
(function (DashboardDemo) {
    angular.module('DashboardDemo', ['ngRoute', 'ngResource']); /*.config(
        ($routeProvider: ng.route.IRouteProvider));*/
})(DashboardDemo || (DashboardDemo = {}));
