var DashboardDemo;
(function (DashboardDemo) {
    var DashboardController = (function () {
        function DashboardController(dashboardService, $location) {
            var _this = this;
            this.dashboardService = dashboardService;
            this.$location = $location;
            this.citAvg = 0;
            this.citCount = 0;
            this.amountDue = 0;
            this.numberDue = 0;
            this.ARavg = 0;
            this.ageAve = 0;
            //Get the CIT values and populate the associated variables with their values
            this.citRecaps = dashboardService.listCits().$promise.then(function (results) {
                var tempsum = 0;
                for (var i = 0; i < results.length; i++) {
                    _this.citCount++;
                    tempsum += results[i].transactionAmount;
                }
                _this.citAvg = tempsum / _this.citCount;
                _this.citTotal = tempsum;
            });
            //Get the vehicle ARs and populate the variables with their values
            this.vehicleARs = dashboardService.listVAR().$promise.then(function (results) {
                var tempsum = 0;
                var tempAge = 0;
                for (var i = 0; i < results.length; i++) {
                    _this.numberDue++;
                    tempsum += results[i].transactionAmount;
                    tempAge += results[i].age;
                }
                _this.ARavg = tempsum / _this.numberDue;
                _this.amountDue = tempsum;
                _this.ageAve = Math.round(tempAge / _this.numberDue);
            });
        }
        return DashboardController;
    })();
    DashboardDemo.DashboardController = DashboardController;
    angular.module('DashboardDemo').controller('dashboardController', DashboardController);
})(DashboardDemo || (DashboardDemo = {}));
